using System;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class VulnerableUpload : Page
{
    protected void UploadButton_Click(object sender, EventArgs e)
    {
        if (FileUploadControl.HasFile)
        {
            try
            {
                // **[HIGH-RISK VULNERABILITY POINT]**
                // 1. No validation on file extension or MIME type.
                // 2. Uses the client-provided filename, risking Path Traversal or overwrites.
                // 3. Files are saved to an executable directory within the web root.

                // Define the save path (assuming an 'uploads' folder exists in the web root)
                string savePath = Server.MapPath(".");

                // Ensure the directory exists
                if (!Directory.Exists(savePath))
                {
                    Directory.CreateDirectory(savePath);
                }

                // Get the original filename from the user input
                string fileName = FileUploadControl.FileName;
                string filePath = Path.Combine(savePath, fileName);

                // Save the file (no content check performed)
                FileUploadControl.PostedFile.SaveAs(filePath);

                // Display success message and a link for easy testing
                StatusLabel.Text = "File upload successful!<br />Filename: " + fileName + "<br />Save Path: " + filePath;
            
            }
            catch (Exception ex)
            {
                StatusLabel.Text = "File upload failed: " + ex.Message;
            }
        }
        else
        {
            StatusLabel.Text = "Please select a file first.";
        }
    }
}